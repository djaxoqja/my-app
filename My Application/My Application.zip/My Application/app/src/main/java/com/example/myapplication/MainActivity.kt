package com.example.myapplication

import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // View Binding 초기화
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // WebView 설정
        binding.webView.apply {
            // WebView 설정
            settings.apply {
                javaScriptEnabled = true // JavaScript 활성화
                domStorageEnabled = true // DOM Storage 활성화
                javaScriptCanOpenWindowsAutomatically = true // JavaScript 창 자동 열기 허용
                loadWithOverviewMode = true // 웹 페이지 전체를 화면에 맞게 로드
                useWideViewPort = true // ViewPort 설정 허용
            }

            // WebViewClient 설정
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                    url?.let {
                        if (it.startsWith("http://localhost:8080/auth/kakao")) {
                            // 리디렉션 URL에서 액세스 토큰 추출
                            val uri = Uri.parse(it)
                            val token = uri.getQueryParameter("access_token")
                            token?.let { accessToken ->
                                Log.d("KakaoLogin", "Access Token: $accessToken")
                                // 로그인 성공 후 추가 작업 수행 (예: 토큰 저장, 화면 전환 등)
                            }
                            return true // 리디렉션 URL 처리 완료
                        }
                        view?.loadUrl(it) // 리디렉션이 아닌 URL은 WebView에 로드
                    }
                    return true
                }
            }
        }

        // 쿠키 설정
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true) // 쿠키 허용
        cookieManager.setAcceptThirdPartyCookies(binding.webView, true) // 서드파티 쿠키 허용

        // 디버깅 활성화 (개발용)
        WebView.setWebContentsDebuggingEnabled(true)

        // URL 로드
        binding.webView.loadUrl("https://djaxoqja.github.io/my-app")
    }
}
